
# IT2120 - Probability and Statistics
# Lab Sheet 10 : Chi-Squared Tests
# Student ID: IT24103504

# 0️⃣ Set working directory
setwd ("C:\\Users\\MSI\\Desktop\\PS\\LAB_10")

# 1️⃣ Load dataset
data <- read.csv("Data.csv")
View(data)
str(data)


# Observed frequencies
customers <- c(55, 62, 43, 46, 50)
days <- c("Mon", "Tue", "Wed", "Thu", "Fri")


result1 <- chisq.test(customers, p = rep(1/5, 5))

# Show results
print(result1)


result1$expected

tasks <- read.csv("C:/Users/USER/Desktop/Lab 10/Data.csv", row.names = 1)

# View data
View(tasks)

result2 <- chisq.test(tasks)

# Display results
print(result2)

# Expected frequencies
result2$expected

# Example: assume these are recorded purchases
snack_counts <- c(45, 39, 33, 43)   # Replace with your actual data if in CSV
snack_types <- c("A", "B", "C", "D")


result3 <- chisq.test(snack_counts, p = rep(1/4, 4))

# Display results
print(result3)
result3$expected


# OPTIONAL: Save output to file
sink("ChiSquare_Lab10_Output.txt")
cat("=== Question 1: Shop Owner Test ===\n")
print(result1)
cat("\n=== Question 2: House Tasks Test ===\n")
print(result2)
cat("\n=== Question 3: Vending Machine Test ===\n")
print(result3)
sink()